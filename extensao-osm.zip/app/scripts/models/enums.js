export class AreaType {
  static Relation = 'relation';
  static Way = 'way';
}

export class AreaTypeContract {
  static Relation = 0n;
  static Way = 1n;
}

export class ChangetsetStatus {
  static Minted = 'Minted';
  static New = 'New';
  static Invalid = 'Invalid';
}

export class ContentSelection {
  static MyChangesets = 'my-changesets';
  static MyNFTs = 'my-nfts';
  static OpenProjects = 'open-projects';
  static MyProjects = 'my-projects';
}

export class MetaMaskStatus {
  static Connected = 'Connect';
  static Disconnected = 'Disconnected';
  static NotInstalled = 'NotInstalled';
}


export class SidePanelPage {
  static Home = '../../templates/sidepanel.html';
  static CreateProject = '../../templates/create-project.html';
  static NotLogged = '../../templates/not-logged.html';
}