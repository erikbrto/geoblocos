export const NFT_STORAGE_API_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkaWQ6ZXRocjoweDlCZWNENzUyREY0OTdlNzEyQjQzNGI4QmEyMjBBNDRjNTFCNTc1MzkiLCJpc3MiOiJuZnQtc3RvcmFnZSIsImlhdCI6MTY4NDI2MDIzNjQ4NCwibmFtZSI6IkNoYW5nZXNldE9TTSJ9.-OrpS0MzshoxBV_tdhCfAZl2CIt4tGaLqxFB0oEJHgA';
export const OSM_ROOT_URL = 'https://www.openstreetmap.org';
export const OSM_API_URL = 'https://www.openstreetmap.org/api/0.6';
export const OVERPASS_API = 'https://overpass-api.de/api/interpreter';
export const ETHEREUM_NETWORK = 'sepolia';
export const NFT_CONTRACT_ADRESS = '0x268933E05A5b4cdB9FA2CF4c0d92E40521eBfc6F';
export const DATABASE_CONTRACT_ADRESS = '0x69aD2D5EC2Cd02593BDeE89c16054Cc297740080';

// module.exports = {
//     NFT_STORAGE_API_KEY,
//     OSM_ROOT_URL,
//     OSM_API_URL,
//     ETHEREUM_NETWORK,
//     INFURA_API_KEY,
//     WEB3_INFURA_PROVIDER,
//     CONTRACT_ADRESS
// };
